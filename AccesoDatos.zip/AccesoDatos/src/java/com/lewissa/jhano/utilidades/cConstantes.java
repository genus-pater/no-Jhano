/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.lewissa.jhano.utilidades;

/**
 *
 * @author Usuario
 */
public class cConstantes {
    public static final String URL="jdbc:postgresql://192.168.46.128:5432/ejemplo";
    public static final String DRIVER="org.postgresql.Driver";
    public static final String USER="publico";
    public static final String PASSWORD="123456";
}
